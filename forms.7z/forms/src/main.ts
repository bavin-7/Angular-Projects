import { bootstrapApplication } from '@angular/platform-browser';
import { SigninComponent } from './app/signin/signin.component';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { LoginComponent } from './app/login/login.component';


bootstrapApplication(LoginComponent, SigninComponent {
  providers: [
    provideRouter([]), 
    provideHttpClient()
  ]
})
.catch(err => console.error(err));
